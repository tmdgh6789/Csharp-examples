﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DtmfDetection.NAudio")]
[assembly: AssemblyDescription("Library that extends NAudio with means to detect DTMF tones in audio data.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Robert Hofmann")]
[assembly: AssemblyProduct("DtmfDetection.NAudio")]
[assembly: AssemblyCopyright("Copyright © 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("e180cb2c-0861-4fca-8cfb-1e6632c83198")]
[assembly: AssemblyVersion("0.9")]