﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DtmfDetection")]
[assembly: AssemblyDescription("Library for the detection of DTMF tones in audio data.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Robert Hofmann")]
[assembly: AssemblyProduct("DtmfDetection")]
[assembly: AssemblyCopyright("Copyright © 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("56e96006-4e6b-4708-9228-270595daec0e")]
[assembly: AssemblyVersion("0.9")]