﻿namespace DtmfDetection
{
    public enum PhoneKey
    {
        None,
        Zero,
        One,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Star,
        Hash,
        A,
        B,
        C,
        D
    }
}
